# Shulker Loot Adjustments for Minecraft 1.14.x
 This datapack introduces loot table changes that guarantees the player 2 shulker shells as opposed to the percentage chance of it dropping 1 or more.
 This datapack was written for use in The Baked Potatarium Minecraft server but can be loaded into any Minecraft world as a datapack.

## Installation Instructions
1. Download the latest release (ZIP format)
2. Put the ZIP folder in your Minecraft Save's "datapack" folder.
3. Load your Minecraft save or if already in-game, type /reload.
The datapack should automatically activate. You can verify this by typing "/datapack list" and ShulkerLoot.zip should appear.

## Releases
[Download the latest release (v1.0.0)](https://github.com/RyanWalpoleEnterprises/Shulker-Loot-Adjustments-Datapack/raw/master/releases/ShulkerLoot.zip)