# Changelog

## Version 1.1.0
1. Added "Killed by Player" to the Skull Description.
2. Made the drop chance 100% - omitted the tag for random chance with looting.

## Version 1.0.0
1. Release version.