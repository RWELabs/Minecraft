# Player Head Drops for Minecraft 1.14.x
 This datapack introduces loot table changes that allow for the introduction of player head drops upon death in Minecraft 1.14.x.
 This datapack was written for use in The Baked Potatarium Minecraft server but can be loaded into any Minecraft world as a datapack.
